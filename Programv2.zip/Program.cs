﻿using Microsoft.Extensions.Configuration;

//When adding configuration providers with IConfigurationBuilder.Add,
//the added configuration provider is added to the end of the end of the IConfigurationSource list.
//When keys are found by multiple providers, the last provider to read the key overrides previous providers.

/*
 * 
 * appsettings.json file
 * appsettings.{env.EnvironmentName}.json file
 * The local User Secrets File (local development environment only)
 * Environment Variables
 * Command Line Arguments
 */

//this comees from launch settings.
var environmentName = Environment.GetEnvironmentVariable("environment"); // launchSettings.json or actual system env variables

// last in overrides earlier
var configBuilder = new ConfigurationBuilder()
    .AddJsonFile($"appsettings.{environmentName}.json")
    .AddJsonFile("appsettings.json")
    .AddCommandLine(args)
    .AddEnvironmentVariables();
    //TODO:  AddAWSSecrets - make it's own middleware / copy  / reference --> https://andrewlock.net/secure-secrets-storage-for-asp-net-core-with-aws-secrets-manager-part-1/ at bottom

// Strongly types config that can be injected into services
var config = configBuilder.Build();
var myConfig = new StronglyTypedConfigThing();
config.Bind("mySection", myConfig);
Console.WriteLine(myConfig.Name);

// single config value
var configValue = config["name"];
Console.WriteLine(configValue);

var f = Console.ReadKey().Key;

public class StronglyTypedConfigThing
{
    public string Name { get; set; } = string.Empty;
}